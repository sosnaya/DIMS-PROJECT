import sqlite3       # connect to db and execute SQL queries
import pandas as pd  # read CSV files, manipulate data and interact with SQLite db
import os            # use operating system-dependent functionality

# List of column names for the 'documents' table in the database.
valid_column_names = ['records_id','name', 'classifier', 'network', 'document_path', 'pdm_num', 'descr', 'rea', 'date_verified', 'version']
# List of column names for the 'model_inputs' table in the database.
valid_model_inputs_column_names = ['records_model_id' ,'model_name', 'classifier', 'variable_name', 'descr', 'nom_value', 'distribution', 'mean', 'sigma', 'lower_val', 'upper_val', 'units', 'build', 'document_id']


# Function to load CSV files
# Defines 'load_csv' function takes file path as input and returns the contents in CSV file
# as a pandas dataframe
def load_csv(file_path):
    # 'pd.read_csv() is a function call from pandas library, then read its content 'file_path'
    # dataframe is a tabular data structure used in pandas to represents data in rows and columns
    return pd.read_csv(file_path)

# Function to create a table in the SQLite database if it doesn't exist
# Define 'create_table_if_not_exists' with 3 arguements, conn=SQLite DB connection, 
#   table_name= name of table to be created or check for existence, 
#   columns= individual fields & attributes that make up the structure of the table
def create_table_if_not_exists(conn, table_name, columns):
    # cursor object that allows Python code to execute SQL commands against DB
    cursor = conn.cursor()
    # joins elements from 'columns' list into single string, separated by commas. This string 
    # represent the column definitons for the SQL create table statement
    column_definitions = ', '.join(columns)
    # constructs the SQL query string to create the table if doesn't exist. Uses Python's f-string
    # formatting to insert 'table_name' and 'column_definitions'
    query = f"CREATE TABLE IF NOT EXISTS {table_name} ({column_definitions})"
    # perform SQLite command to create table if it doesn't exist
    cursor.execute(query)
    # save table changes
    conn.commit()

# Function to save in dataframe('df') to SQLite db specificed by 'table_name'
def save_to_database(df, conn, table_name):
    cursor = conn.cursor()
    # check is 'table_name' exist in db, then query check 'sqlite_master' table that contains metadata
    #   about all tables in db, if table exist then return name
    cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table_name,))
    # fetch result of SQL query, if exists then 'existing_table' will be non-null value, indicating it exists
    existing_table = cursor.fetchone()
    if existing_table:
        # save 'df' to specificed table in db, then append if table exist
        df.to_sql(table_name, conn, if_exists='append', index=False)
    else:
        # save 'df' to specified table in db, then specifies if table doesn't exist, then replace 'df'
        #   and creates new table with dat in 'df'
        df.to_sql(table_name, conn, if_exists='replace', index=False)

# Function to process model inputs data stored in 'model_inputs_df, path to SQLite db 'db_file', 
#  and table name in db 'model_inputs'
def check_and_save_model_inputs(model_inputs_df, db_file, model_inputs):
    conn = sqlite3.connect(db_file)
    # Python code interects with db SQLite cursor object
    cursor = conn.cursor()
    # function to create 'model_inputs' table in SQLite db, if it doesn't exist.
    create_table_if_not_exists(conn, model_inputs, [
        'records_model_id INTEGER PRIMARY KEY AUTOINCREMENT',
        'model_name TEXT',
        'classifier TEXT',
        'variable_name TEXT',
        'descr TEXT',
        'nom_value REAL',
        'distribution TEXT',
        'mean REAL',
        'sigma REAL',
        'lower_val REAL',
        'upper_val REAL',
        'units TEXT',
        'build TEXT',
        'document_id INTEGER'
    ])
    # Check for existing records in the table
    cursor.execute(f"SELECT * FROM {model_inputs}")
    existing_records = pd.DataFrame(cursor.fetchall(), columns=valid_model_inputs_column_names)
    # Check for duplicates based on 'model_name', 'variable_name', and 'build'
    duplicates = model_inputs_df[model_inputs_df[['model_name', 'variable_name', 'build']].isin(existing_records[['model_name', 'variable_name', 'build']]).all(1)]
    # print duplicate and rejected records from model_input table
    if not duplicates.empty:
        print("Rejected model_inputs records due to duplication:")
        print(duplicates)
        conn.close()
        # Skip appending records if there are duplicates
        return
    # Append only unique records to the database and close database
    save_to_database(model_inputs_df, conn, model_inputs)
    conn.close()

# Function to process documents data stored in documents_df, path to SQLite db 'db_file', 
# and table name in db 'documents'
def check_and_save_documents(documents_df, db_file, documents):
    conn = sqlite3.connect(db_file)
    # Python code interects with db SQLite cursor object
    cursor = conn.cursor()
    
    # function to create 'model_inputs' table in SQLite db, if it doesn't exist. 
    create_table_if_not_exists(conn, documents, [
        'records_id INTEGER PRIMARY KEY AUTOINCREMENT',
        'name TEXT',
        'classifier TEXT',
        'network TEXT',
        'document_path TEXT',
        'pdm_num INTEGER',
        'descr TEXT',
        'rea TEXT',
        'date_verified TEXT',
        'version TEXT'
    ])
    
    # Check for existing records in the table
    cursor.execute(f"SELECT * FROM {documents}")
    existing_records = pd.DataFrame(cursor.fetchall(), columns=valid_column_names)
    # Check for duplicates based on 'name' and 'pdm_num'
    duplicates = documents_df[documents_df[['name', 'pdm_num']].isin(existing_records[['name', 'pdm_num']]).all(1)]
    # print duplicate and rejected records from document table 
    if not duplicates.empty:
        print("Rejected document records due to duplication:")
        print(duplicates)
        conn.close()
        return  # Skip appending records if there are duplicates
    documents_df.to_sql(documents, conn, if_exists='append', index=False)
    conn.close()

# Function to get the number of records in the database
def get_database_record_count(db_file, table_name):
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
    count = cursor.fetchone()[0]
    conn.close()
    return count

# Function to create joined_data table if not exists
def create_joined_data_table_if_not_exists(conn):
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS joined_data (
            records_id INTEGER PRIMARY KEY AUTOINCREMENT,
            model_name TEXT,
            classifier TEXT,
            variable_name TEXT,
            descr TEXT,
            nom_value REAL,
            distribution TEXT,
            mean REAL,
            sigma REAL,
            lower_val REAL,
            upper_val REAL,
            units TEXT,
            build TEXT,
            document_id INTEGER,
            name TEXT,
            network TEXT,
            document_path TEXT,
            pdm_num INTEGER,
            rea TEXT,
            date_verified TEXT,
            version TEXT
        )
    """)
    conn.commit()

# Function to compare two rows of data from 'joined_data'
# Python code
def compare_simulations(joined_data):
    print("Enter the row numbers you want to compare:")
    row_num1 = int(input("Row 1: "))
    row_num2 = int(input("Row 2: "))
    # retrieves specified row from 'joined_data' df, -1 is used since df 
    #   start at 0-based but database row id show as 1
    row1 = joined_data.iloc[row_num1 - 1] # Adjust for 0-based index
    row2 = joined_data.iloc[row_num2 - 1] # Adjust for 0-based index

    print("Comparison Results:")
    for column in row1.index:
        # convert two rows into string for easy comparsion and expected results
        value1 = str(row1[column])
        value2 = str(row2[column])
        # check if value1 is not equal to value2 then print values not equal to one another
        if value1 != value2:
            print(f"{column}: *{value1}* (Row 1) != *{value2}* (Row 2)")

# Function used to update update column value in documents table by column and row number
# Python code that uses SQLite modules to interact with SQLite db  
#def update_documents_column(column_name, new_value, row_number, conn, documents):
#    cursor = conn.cursor()
 #   cursor.execute(f"UPDATE {documents} SET {column_name}=? WHERE records_id=?", (new_value, row_number))
  #  conn.commit()

# Function used to delete specific row number in documents table by row number
# Python code that uses SQLite modules to interact with SQLite db   
#def delete_documents_by_row_number(row_number, conn, documents):
#    cursor = conn.cursor()
#    cursor.execute(f"DELETE FROM {documents} WHERE records_id=?", (row_number,))
#    conn.commit()

# Function used to update update column value in documents table by column and row number
# Python code that uses SQLite modules to interact with SQLite db
def update_documents_column(column_name, new_value, row_number, conn, documents):
    cursor = conn.cursor()
    # SELECT query counts the number of rows with specified 'row_number' in 'documents' table
    # if row exists then update to specified column with new value for the given row
    try:
        cursor.execute(f"SELECT COUNT(*) FROM {documents} WHERE records_id=?", (row_number,))
        row_exists = cursor.fetchone()[0]
        if row_exists:
            cursor.execute(f"UPDATE {documents} SET {column_name}=? WHERE records_id=?", (new_value, row_number))
            conn.commit()
            print("Update successful.")
        else:
            # if row doesn't exist then valueError executes
            raise ValueError(f"Record with records_id {row_number} not found in {documents}.")
    # If SQLite error occurs, it prints an error message
    except sqlite3.Error as e:
        print(f"Error updating records in {documents}: {e}")
    except ValueError as ve:
        print(ve)
    finally:
        conn.close()

# Function used to delete specific row number in model_inputs table by row number
# Python code that uses SQLite modules to interact with SQLite db 
def delete_documents_by_row_number(row_number, conn, documents):
    cursor = conn.cursor()
     # SELECT query counts the number of rows with specified 'row_number' in 'documents' table
     # if row exist then proceed to delete the row 
    try:
        cursor.execute(f"SELECT COUNT(*) FROM {documents} WHERE records_id=?", (row_number,))
        row_exists = cursor.fetchone()[0]
        if row_exists:
            cursor.execute(f"DELETE FROM {documents} WHERE records_id=?", (row_number,))
            conn.commit()
            print("Deletion successful.")
        # if row doesn't exist then valueError executes
        else:
            raise ValueError(f"Record with records_id {row_number} not found in {documents}.")
    # If SQLite error occurs, it prints an error message
    except sqlite3.Error as e:
        print(f"Error deleting records in {documents}: {e}")
    except ValueError as ve:
        print(ve)
    finally:
        conn.close()
        
# Function used to delete specific row number in model inputs table by row number
# Python code that uses SQLite modules to interact with SQLite db        
def update_model_inputs_column(column_name, new_value, row_number, conn, model_inputs):
    cursor = conn.cursor()
    try:
        cursor.execute(f"SELECT COUNT(*) FROM {model_inputs} WHERE records_model_id=?", (row_number,))
        row_exists = cursor.fetchone()[0]
        if row_exists:
            cursor.execute(f"UPDATE {model_inputs} SET {column_name}=? WHERE records_model_id=?", (new_value, row_number))
            conn.commit()
            print("Update successful.")
        else:
            raise ValueError(f"Record with records_model_id {row_number} not found in {model_inputs}.")
    except sqlite3.Error as e:
        print(f"Error updating records in {model_inputs}: {e}")
    except ValueError as ve:
        print(ve)
    finally:
        conn.close()
# Function used to delete specific row number in model inputs table by row number
# Python code that uses SQLite modules to interact with SQLite db 
def delete_model_input_by_row_number(row_number, conn, model_inputs):
    cursor = conn.cursor()
    try:
        cursor.execute(f"SELECT COUNT(*) FROM {model_inputs} WHERE records_model_id=?", (row_number,))
        row_exists = cursor.fetchone()[0]
        if row_exists:
            cursor.execute(f"DELETE FROM {model_inputs} WHERE records_model_id=?", (row_number,))
            conn.commit()
            print("Deletion successful.")
        else:
            raise ValueError(f"Record with records_model_id {row_number} not found in {model_inputs}.")
    except sqlite3.Error as e:
        print(f"Error deleting records in {model_inputs}: {e}")
    except ValueError as ve:
        print(ve)
    finally:
        conn.close()

def main():
    # Establish connection to the model_inputs and documents database
    conn_model_inputs = sqlite3.connect('model_inputs.db')
    conn_documents = sqlite3.connect('documents.db')
    
    # Display menu options
    print("Please select an option:")
    print("1. Execute importing CSV files to the database")
    print("2. Join model and document databases")
    print("3. Compare Two Simulations from joined table")
    print("4. Update or Delete Records from documents.db")
    print("5. Update or Delete Records from model_inputs.db")
    print("6. Exit")
    
    # Get user choice
    user_choice = input("Enter your choice (1, 2, 3, 4, 5, or 6 to exit): ")
    
    # Check user choice and perform corresponding action
    if user_choice == "1":
        # Load model_inputs.csv into a separate database
        model_inputs_df = load_csv('model_inputs.csv')
        check_and_save_model_inputs(model_inputs_df, 'model_inputs.db', 'model_inputs')

        # Load documents.csv into another separate database
        documents_df = load_csv('documents.csv')
        check_and_save_documents(documents_df, 'documents.db', 'documents')
        
        # Display summary
        print("Number of records found:")
        print(f"model_inputs.csv: {len(model_inputs_df)} records")
        print(f"documents.csv: {len(documents_df)} records")

        # Display the number of records currently in each database
        print("\nNumber of records in databases:")
        print(f"model_inputs.db: {get_database_record_count('model_inputs.db', 'model_inputs')} records")
        print(f"documents.db: {get_database_record_count('documents.db', 'documents')} records")

    elif user_choice == "2":
        # Check if both databases exist
        model_inputs_exist = os.path.isfile('model_inputs.db')
        documents_exist = os.path.isfile('documents.db')

        if not model_inputs_exist or not documents_exist:
            print("Error: One or both of the databases do not exist.")
            exit()
            
        # Connect to the model_inputs database
        conn_model_inputs = sqlite3.connect('model_inputs.db')
        cursor_model_inputs = conn_model_inputs.cursor()
        
        # Connect to the documents database
        conn_documents = sqlite3.connect('documents.db')
        cursor_documents = conn_documents.cursor()

        # Merge data from model_inputs and documents
        model_inputs_data = pd.read_sql_query("SELECT * FROM model_inputs", conn_model_inputs)
        documents_data = pd.read_sql_query("SELECT * FROM documents", conn_documents)

        joined_data = pd.merge(model_inputs_data, documents_data, left_on='document_id', right_on='records_id', how='inner')

        # Check if joined_data table exists in joined_data.db
        if os.path.isfile('joined_data.db'):
            conn_joined_data = sqlite3.connect('joined_data.db')
            cursor_joined_data = conn_joined_data.cursor()
            cursor_joined_data.execute("DELETE FROM joined_data")
            conn_joined_data.commit()
            conn_joined_data.close()

        # Save merged data to joined_data.db
        save_to_database(joined_data, sqlite3.connect('joined_data.db'), 'joined_data')

        print("Joined data saved to 'joined_data.db'")

    elif user_choice == "3":
        # Compare Two Simulations from joined table
        # Read joined data
        conn_joined = sqlite3.connect('joined_data.db')
        joined_data = pd.read_sql_query("SELECT * FROM joined_data", conn_joined)
        conn_joined.close()

        # Call compare_simulations function
        compare_simulations(joined_data)

    elif user_choice == "4":
        print("Update or Delete Records from documents.db")
        action = input("Enter 'update' to update a record or 'delete' to delete a record: ")
        if action == "update":
            column_name = input("Enter the column name you want to update: ")
            new_value = input("Enter the new value: ")
            row_number = input("Enter the 'records_id' number to update: ")
            try:
                row_number = int(row_number)
            except ValueError:
                print("Invalid 'records_id' number. Please enter a valid integer.")
                return

            if column_name not in valid_column_names:  # You need to define valid_column_names
                print(f"Invalid column name '{column_name}'. Please enter a valid column name.")
                return

            update_documents_column(column_name, new_value, row_number, conn_documents, 'documents')
            # Update joined_data table after updating documents
            conn_joined_data = sqlite3.connect('joined_data.db')
            cursor_joined_data = conn_joined_data.cursor()
            cursor_joined_data.execute(f"UPDATE joined_data SET {column_name}=? WHERE records_id=?", (new_value, row_number))
            conn_joined_data.commit()
            conn_joined_data.close()
        elif action == "delete":
            row_number_to_delete = input("Enter the 'records_id' number to delete: ")
            try:
                row_number_to_delete = int(row_number_to_delete)
            except ValueError:
                print("Invalid 'records_id' number. Please enter a valid integer.")
                return

            delete_documents_by_row_number(row_number_to_delete, conn_documents, 'documents')
            # Delete corresponding row from joined_data table after deleting from documents
            conn_joined_data = sqlite3.connect('joined_data.db')
            cursor_joined_data = conn_joined_data.cursor()
            cursor_joined_data.execute(f"DELETE FROM joined_data WHERE records_id=?", (row_number_to_delete,))
            conn_joined_data.commit()
            conn_joined_data.close()
        else:
            print("Invalid action. Please enter 'update' or 'delete'.")

    elif user_choice == "5":
        print("Update or Delete Records from model_inputs.db")
        action = input("Enter 'update' to update a record or 'delete' to delete a record: ")
        if action == "update":
            column_name = input("Enter the column name you want to update: ")
            new_value = input("Enter the new value: ")
            row_number = input("Enter the 'records_model_id' number to update: ")
            try:
                row_number = int(row_number)
            except ValueError:
                print("Invalid 'records_model_id' number. Please enter a valid integer.")
                return

            if column_name not in valid_model_inputs_column_names:
                print(f"Invalid column name '{column_name}'. Please enter a valid column name.")
                return

            update_model_inputs_column(column_name, new_value, row_number, conn_model_inputs, 'model_inputs')
            # Update joined_data table after updating model_inputs
            conn_joined_data = sqlite3.connect('joined_data.db')
            cursor_joined_data = conn_joined_data.cursor()
            cursor_joined_data.execute(f"UPDATE joined_data SET {column_name}=? WHERE records_model_id=?", (new_value, row_number))
            conn_joined_data.commit()
            conn_joined_data.close()
        elif action == "delete":
            row_number_to_delete = input("Enter the 'records_model_id' number to delete: ")
            try:
                row_number_to_delete = int(row_number_to_delete)
            except ValueError:
                print("Invalid 'records_model_id' number. Please enter a valid integer.")
                return

            delete_model_input_by_row_number(row_number_to_delete, conn_model_inputs, 'model_inputs')
            # Delete corresponding row from joined_data table after deleting from model_inputs
            conn_joined_data = sqlite3.connect('joined_data.db')
            cursor_joined_data = conn_joined_data.cursor()
            cursor_joined_data.execute(f"DELETE FROM joined_data WHERE records_model_id=?", (row_number_to_delete,))
            conn_joined_data.commit()
            conn_joined_data.close()
        else:
            print("Invalid action. Please enter 'update' or 'delete'.")
    elif user_choice == "6":
        print("Exiting program.")
        exit()
    else:
        print("Invalid choice. Please enter 1, 2, 3, 4, 5, or 6.")

    main()

if __name__ == "__main__":
    main()