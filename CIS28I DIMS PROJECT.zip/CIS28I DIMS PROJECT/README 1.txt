Step-by-step live demo of DIMS Project

https://youtu.be/KMBDOF6R7h0